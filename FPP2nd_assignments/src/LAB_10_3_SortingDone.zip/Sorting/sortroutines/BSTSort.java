package sortroutines;

import runtime.Sorter;


public class BSTSort extends Sorter {
	MyBST btree = new MyBST();
	

	// It takes as input an array and builds a BST tree from it.
	public void insertAll(int[] array) {
		for (int i = 0; i < array.length; i++) {
			btree.insert(array[i]);
		}
	}

	// It traverses the BST and returns all its elements in a sorted array
	public int[] readIntoArray() {
		return  btree.getAsArray();
	}

	@Override
	public int[] sort(int[] arr) {
		int[] sArr = new int[arr.length];
		insertAll(arr);
		sArr = readIntoArray();

		// TODO Auto-generated method stub
		return sArr;
	}
}
